import re

# Marqueurs pour délimiter la section des règles dans le system_prompt
RULES_START = "=== STELAR_RULES_START ==="
RULES_END   = "=== STELAR_RULES_END ==="

def register(api):
    """
    Plugin pour gérer des règles IA persistantes.
    Les règles sont stockées dans config.json sous la clé "rules_list".
    Elles sont injectées dans le system_prompt entre des marqueurs spéciaux.
    """

    # Récupère la config en mémoire
    config = api.get_config()

    # Initialise la liste de règles si elle n'existe pas
    if "rules_list" not in config:
        config["rules_list"] = []
        api.save_config()

    def extraire_system_prompt_sans_regles():
        """Retourne le system_prompt actuel en supprimant la section des règles (si présente)."""
        prompt = config.get("system_prompt", "")
        # Cherche les marqueurs
        start_idx = prompt.find(RULES_START)
        if start_idx == -1:
            return prompt  # pas de section règles
        end_idx = prompt.find(RULES_END, start_idx)
        if end_idx == -1:
            # Si le marqueur de fin est absent, on coupe à partir du début
            return prompt[:start_idx].strip()
        # On retourne la partie avant le start + la partie après le end
        return (prompt[:start_idx] + prompt[end_idx + len(RULES_END):]).strip()

    def reecrire_prompt_avec_regles():
        """Reconstruit le system_prompt avec les règles actuelles et le sauvegarde."""
        base = extraire_system_prompt_sans_regles()
        rules = config.get("rules_list", [])
        if rules:
            # Construit la section règles
            rules_section = f"\n\n{RULES_START}\n"
            rules_section += "Règles que l'assistant doit absolument respecter :\n\n"
            for i, r in enumerate(rules, 1):
                rules_section += f"{i}. {r}\n"
            rules_section += RULES_END
            nouveau_prompt = base + rules_section
        else:
            # Pas de règles : on garde juste la base (sans marqueurs)
            nouveau_prompt = base

        config["system_prompt"] = nouveau_prompt
        api.save_config()

    def cmd_rules(args):
        """
        /rules                    → affiche la liste des règles actuelles
        /rules add <texte>        → ajoute une nouvelle règle
        /rules remove <numéro>    → supprime la règle n°<numéro> (1-indexé)
        /rules clear              → supprime toutes les règles
        """
        if not args:
            # Afficher les règles
            rules = config.get("rules_list", [])
            if not rules:
                api.print_system("Aucune règle définie.")
                api.print_system("Utilisez /rules add <texte> pour en ajouter.")
                return

            api.print_box("Règles actives", [f"{i}. {r}" for i, r in enumerate(rules, 1)])
            return

        action = args[0].lower()

        if action == "add":
            if len(args) < 2:
                api.print_error("Usage : /rules add <règle>")
                return
            texte = " ".join(args[1:])
            config["rules_list"].append(texte)
            reecrire_prompt_avec_regles()
            api.print_success(f"✅ Règle ajoutée : « {texte} »")
            api.print_system("Cette règle s'appliquera aux prochaines réponses de l'IA.")

        elif action == "remove":
            if len(args) < 2:
                api.print_error("Usage : /rules remove <numéro>")
                return
            try:
                index = int(args[1]) - 1
                rules = config.get("rules_list", [])
                if index < 0 or index >= len(rules):
                    api.print_error(f"Numéro invalide. Il y a {len(rules)} règle(s).")
                    return
                supprimee = rules.pop(index)
                reecrire_prompt_avec_regles()
                api.print_success(f"✅ Règle supprimée : « {supprimee} »")
            except ValueError:
                api.print_error("Le numéro doit être un entier.")

        elif action == "clear":
            # Demander confirmation
            if not api.ask_yes_no("Supprimer toutes les règles ?", default_no=True):
                api.print_system("Annulé.")
                return
            config["rules_list"] = []
            reecrire_prompt_avec_regles()
            api.print_success("✅ Toutes les règles ont été supprimées.")

        else:
            api.print_error(f"Action inconnue : {action}")
            api.print_system("Utilisation : /rules [add|remove|clear]")

    return {
        "/rules": cmd_rules
    }
