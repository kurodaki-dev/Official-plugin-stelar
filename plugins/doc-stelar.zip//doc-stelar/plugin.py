import http.server
import socketserver
import threading
import os
import subprocess
import time

# État global du serveur
serveur = {
    "thread": None,
    "httpd": None,
    "running": False,
    "port": 20000
}

# Handler silencieux : pas de logs dans le terminal
class SilentHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Ne rien afficher

def register(api):
    """Enregistrement du plugin."""

    def cmd_doc(args):
        if not args:
            args = []

        # Commande d'arrêt
        if args and args[0].lower() == "stop":
            return arreter_serveur(api)

        # Port personnalisé ?
        port = 20000
        if args and args[0].isdigit():
            port = int(args[0])

        # Vérification du dossier 'site'
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
        site_dir = os.path.join(plugin_dir, "site")

        if not os.path.isdir(site_dir):
            api.print_error(f"Le dossier 'site' est introuvable dans : {plugin_dir}")
            api.print_system("Créez un dossier 'site' dans le plugin avec vos fichiers HTML/Markdown.")
            return

        if serveur["running"]:
            api.print_warn(f"Le serveur tourne déjà sur http://localhost:{serveur['port']}")
            api.print_system("Accédez-y avec votre navigateur.")
            api.print_system("Pour l'arrêter : /doc stop")
            return

        demarrer_serveur(api, site_dir, port)

    return {
        "/doc": cmd_doc,
    }


def demarrer_serveur(api, site_dir, port):
    """Lance le serveur HTTP dans un thread silencieux."""
    try:
        httpd = socketserver.TCPServer(("", port), SilentHTTPRequestHandler)
    except OSError as e:
        api.print_error(f"Impossible d'écouter sur le port {port} : {e}")
        return

    # Sauvegarde du répertoire courant
    ancien_cwd = os.getcwd()

    def servir():
        try:
            os.chdir(site_dir)
            api.print_success(f"Serveur démarré sur http://localhost:{port}")
            api.print_system(f"Dossier servi : {site_dir}")
            api.print_system(f"Ouvrez http://localhost:{port} dans votre navigateur.")
            api.print_system("Pour arrêter : /doc stop")

            # Ouvre w3m en arrière-plan (si disponible) sans bloquer
            try:
                subprocess.Popen(
                    ["w3m", f"http://localhost:{port}/index.html"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            except FileNotFoundError:
                pass  # w3m pas installé, l'utilisateur ouvrira manuellement

            httpd.serve_forever()

        except Exception as e:
            # Ignore les erreurs de connexion (BrokenPipe, etc.)
            if not isinstance(e, (BrokenPipeError, ConnectionAbortedError, ConnectionResetError)):
                api.print_error(f"Erreur serveur : {e}")
        finally:
            os.chdir(ancien_cwd)
            serveur["running"] = False
            serveur["httpd"] = None
            serveur["thread"] = None
            api.print_system("Serveur arrêté.")

    # Lancement du thread (daemon = s'arrête avec Stelar)
    thread = threading.Thread(target=servir, daemon=True)
    thread.start()

    serveur["thread"] = thread
    serveur["httpd"] = httpd
    serveur["running"] = True
    serveur["port"] = port


def arreter_serveur(api):
    """Arrête le serveur proprement."""
    if not serveur["running"]:
        api.print_warn("Aucun serveur en cours d'exécution.")
        return

    try:
        serveur["httpd"].shutdown()
        api.print_success("Arrêt du serveur en cours...")
        time.sleep(0.5)  # laisse le temps au thread de se terminer
    except Exception as e:
        api.print_error(f"Erreur lors de l'arrêt : {e}")
