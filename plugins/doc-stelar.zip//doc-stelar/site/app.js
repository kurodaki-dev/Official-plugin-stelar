const markdownFile = "DOCUMENTATION.md";
const documentElement = document.querySelector("#document");
const tocElement = document.querySelector("#table-of-contents");
const refreshButton = document.querySelector("#refresh-button");

const escapeHtml = (text) => text.replace(/[&<>"]/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"
}[character]));

function slugify(value, used) {
  const base = value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "section";
  const count = used.get(base) || 0;
  used.set(base, count + 1);
  return count ? `${base}-${count + 1}` : base;
}

function inline(markdown) {
  let value = escapeHtml(markdown);
  value = value.replace(/`([^`]+)`/g, "<code>$1</code>");
  value = value.replace(/!\[([^\]]*)\]\(([^ )]+)(?:\s+&quot;[^&]*&quot;)?\)/g, '<img alt="$1" src="$2">');
  value = value.replace(/\[([^\]]+)\]\(([^ )]+)(?:\s+&quot;[^&]*&quot;)?\)/g, '<a href="$2">$1</a>');
  value = value.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/__([^_]+)__/g, "<strong>$1</strong>");
  value = value.replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, "<em>$1</em>");
  return value;
}

function isTableDivider(line) { return /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(line); }
function tableCells(line) { return line.trim().replace(/^\||\|$/g, "").split("|").map((cell) => cell.trim()); }

function renderMarkdown(markdown) {
  const lines = markdown.replace(/\r\n?/g, "\n").split("\n");
  const usedIds = new Map();
  const headings = [];
  const output = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index];
    if (/^```/.test(line)) {
      const language = line.slice(3).trim(); let code = []; index++;
      while (index < lines.length && !/^```/.test(lines[index])) code.push(lines[index++]);
      output.push(`<pre><code class="language-${escapeHtml(language)}">${escapeHtml(code.join("\n"))}</code></pre>`); index++; continue;
    }
    const heading = line.match(/^(#{1,4})\s+(.+?)\s*#*\s*$/);
    if (heading) {
      const level = heading[1].length, text = heading[2], id = slugify(text, usedIds);
      headings.push({ level, text, id }); output.push(`<h${level} id="${id}">${inline(text)}</h${level}>`); index++; continue;
    }
    if (/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(line)) { output.push("<hr>"); index++; continue; }
    if (index + 1 < lines.length && line.includes("|") && isTableDivider(lines[index + 1])) {
      const headers = tableCells(line); index += 2; const rows = [];
      while (index < lines.length && lines[index].includes("|") && lines[index].trim()) rows.push(tableCells(lines[index++]));
      output.push(`<div class="table-scroll"><table><thead><tr>${headers.map((cell) => `<th>${inline(cell)}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${headers.map((_, i) => `<td>${inline(row[i] || "")}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`); continue;
    }
    if (/^>\s?/.test(line)) {
      const quote = []; while (index < lines.length && /^>\s?/.test(lines[index])) quote.push(lines[index++].replace(/^>\s?/, ""));
      output.push(`<blockquote>${quote.map(inline).join("<br>")}</blockquote>`); continue;
    }
    const list = line.match(/^\s*([-*+] |\d+\. )(.+)$/);
    if (list) {
      const ordered = /^\s*\d+\. /.test(line), tag = ordered ? "ol" : "ul", items = [];
      while (index < lines.length) { const item = lines[index].match(ordered ? /^\s*\d+\.\s+(.+)$/ : /^\s*[-*+]\s+(.+)$/); if (!item) break; items.push(`<li>${inline(item[1])}</li>`); index++; }
      output.push(`<${tag}>${items.join("")}</${tag}>`); continue;
    }
    if (!line.trim()) { index++; continue; }
    const paragraph = [line]; index++;
    while (index < lines.length && lines[index].trim() && !/^(#{1,4}\s|```|>|\s*[-*+]\s+|\s*\d+\.\s+)/.test(lines[index]) && !(lines[index].includes("|") && isTableDivider(lines[index + 1] || ""))) paragraph.push(lines[index++]);
    output.push(`<p>${inline(paragraph.join("\n")).replace(/\n/g, "<br>")}</p>`);
  }
  return { html: output.join("\n"), headings };
}

function makeToc(headings) {
  tocElement.innerHTML = headings.filter((heading) => heading.level > 1).map(({ level, text, id }) =>
    `<a class="toc-link level-${level}" href="#${id}" data-target="${id}">${text.replace(/<[^>]*>/g, "")}</a>`
  ).join("");
  const links = [...tocElement.querySelectorAll(".toc-link")];
  const activate = () => {
    const current = [...document.querySelectorAll("h2, h3, h4")].filter((heading) => heading.getBoundingClientRect().top < 145).pop();
    links.forEach((link) => link.classList.toggle("active", link.dataset.target === current?.id));
  };
  addEventListener("scroll", activate, { passive: true }); activate();
}

async function copyText(text) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.append(textarea);
  textarea.select();
  document.execCommand("copy");
  textarea.remove();
}

function addCopyButtons() {
  documentElement.querySelectorAll("pre").forEach((block) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "copy-code-button";
    button.textContent = "Copier";
    button.setAttribute("aria-label", "Copier ce bloc de texte");
    button.addEventListener("click", async () => {
      try {
        await copyText(block.querySelector("code")?.textContent || "");
        button.textContent = "Copié !";
      } catch {
        button.textContent = "À réessayer";
      }
      window.setTimeout(() => { button.textContent = "Copier"; }, 1600);
    });
    block.append(button);
  });
}

async function loadDocumentation() {
  refreshButton.classList.add("is-loading"); refreshButton.disabled = true;
  try {
    // URL simple et relative : compatible avec le serveur de prévisualisation
    // comme avec la version publiée du projet.
    const response = await fetch(`./${markdownFile}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`Erreur ${response.status}`);
    const { html, headings } = renderMarkdown(await response.text());
    documentElement.innerHTML = html;
    addCopyButtons();
    makeToc(headings);
    if (location.hash) {
      const targetId = decodeURIComponent(location.hash.slice(1));
      document.getElementById(targetId)?.scrollIntoView();
    }
  } catch (error) {
    documentElement.innerHTML = `<div class="error">Impossible de charger <code>${markdownFile}</code> — ${error.message}</div>`;
  } finally {
    refreshButton.classList.remove("is-loading"); refreshButton.disabled = false;
  }
}

refreshButton.addEventListener("click", loadDocumentation);
loadDocumentation();
